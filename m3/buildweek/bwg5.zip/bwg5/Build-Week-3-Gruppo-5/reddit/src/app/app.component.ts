import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'reddit';
}

export class OpenDialog {

  constructor(public dialog: MatDialog){}

  openDialog():void {
    // const dialogRef = this.dialog.open()
  }
}
