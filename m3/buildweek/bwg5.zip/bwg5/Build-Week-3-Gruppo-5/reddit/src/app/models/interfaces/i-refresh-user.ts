export interface IRefreshUser {
  access_token:string;
  expires_in:string;
  id_token:string;
  project_id:string;
  refresh_token:string;
  token_type:string;
  user_id:string;
}
