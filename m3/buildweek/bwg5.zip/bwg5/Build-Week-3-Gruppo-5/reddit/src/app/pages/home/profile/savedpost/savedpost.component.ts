import { Component } from '@angular/core';

@Component({
  selector: 'app-savedpost',
  templateUrl: './savedpost.component.html',
  styleUrls: ['./savedpost.component.scss']
})
export class SavedpostComponent {

}
