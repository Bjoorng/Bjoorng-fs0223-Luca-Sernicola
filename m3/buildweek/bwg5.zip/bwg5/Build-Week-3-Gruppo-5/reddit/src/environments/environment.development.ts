export const environment = {
  /* url: "https://reddit-clone-6c15e-default-rtdb.europe-west1.firebasedatabase.app",
  usersUrl: "https://reddit-clone-6c15e-default-rtdb.europe-west1.firebasedatabase.app/users.json",
  postsUrl: "https://reddit-clone-6c15e-default-rtdb.europe-west1.firebasedatabase.app/posts.json",
  commentsUrl: "https://reddit-clone-6c15e-default-rtdb.europe-west1.firebasedatabase.app/commments.json",
  regUrl: "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyAFutPXX9lgXuy8EVDUNUsyhHZTMwkHl3k",
  logUrl: "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyAFutPXX9lgXuy8EVDUNUsyhHZTMwkHl3k",
  refreshUrl: "https://securetoken.googleapis.com/v1/token?key=AIzaSyAFutPXX9lgXuy8EVDUNUsyhHZTMwkHl3k",
  editUser: "https://reddit-clone-6c15e-default-rtdb.europe-west1.firebasedatabase.app/users/",
  editPost: "https://reddit-clone-6c15e-default-rtdb.europe-west1.firebasedatabase.app/posts/" */
  url: "https://red-2-f17d9-default-rtdb.europe-west1.firebasedatabase.app",
  usersUrl: "https://red-2-f17d9-default-rtdb.europe-west1.firebasedatabase.app/users.json",
  postsUrl: "https://red-2-f17d9-default-rtdb.europe-west1.firebasedatabase.app/posts.json",
  commentsUrl: "https://red-2-f17d9-default-rtdb.europe-west1.firebasedatabase.app/commments.json",
  regUrl: "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyAmH6Raw2_xaHtGQURY40cogSge088CUmA",
  logUrl: "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyAmH6Raw2_xaHtGQURY40cogSge088CUmA",
  refreshUrl: "https://securetoken.googleapis.com/v1/token?key=AIzaSyAmH6Raw2_xaHtGQURY40cogSge088CUmA",
  editUser: "https://red-2-f17d9-default-rtdb.europe-west1.firebasedatabase.app/users/",
  editPost: "https://red-2-f17d9-default-rtdb.europe-west1.firebasedatabase.app/posts/"
};
